package advanced;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Graphs {
	static class Edge {
		int src, dest;

		Edge(int src, int dest)
		{
			this.src = src;
			this.dest = dest;
		}
	};
	List<List<Integer>> adj = new ArrayList<>();

	public Graphs(List<Edge> edges)
	{
		for (int i = 0; i < edges.size(); i++)
			adj.add(i, new ArrayList<>());

		for (Edge current : edges)
		{
			adj.get(current.src).add(current.dest);
		}
	}

	private static void printGraph(Graphs graph)
	{
		int src = 0;
		int n = graph.adj.size();

		while (src < n)
		{
			for (int dest : graph.adj.get(src))
				System.out.print("(" + src + " --> " + dest + ")");

			System.out.println();
			src++;
		}
	}
	public static void main (String[] args)
	{
		List<Edge> edges = Arrays.asList(new Edge(0, 2), new Edge(1, 34), 
								new Edge(2, 878), new Edge(3, 98),new Edge(4, 234), 
								new Edge(5, 8), new Edge(6, 7),new Edge(6, 123),new Edge(7, 7879),new Edge(8, 45),new Edge(9, 123));

		Graphs graph = new Graphs(edges);

		printGraph(graph);
	}
}


