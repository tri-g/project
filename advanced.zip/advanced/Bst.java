package advanced;

import advanced.Tree.Node;

public class Bst {
	Node root;
	static class Node{
		int key;
		Node left;
		Node right;
		Node(int item){
			key=item;
			left=right=null;
		}	
	}
	Bst(){
		root=null;
	}
	public Node insert(Node root,int key)
	{
		if(root==null)
		{
			root=new Node(key);
			return root;
		}
		if(key<root.key)
		{
			root.left=insert(root.left,key);
		}
		else if(key>root.key) {
			root.right=insert(root.right,key);
		}
		return root;
	}
	public void inorder(Node root) {
		if(root==null)
		{
			return;
		}
		inorder(root.left);
		System.out.print(root.key+" ");
		inorder(root.right);
	}
	public Node search(Node root, int key) 
	{ 
	    if (root==null || root.key==key) 
	        return root; 
	    if (root.key > key) 
	        return search(root.left, key); 
	    return search(root.right, key); 
	}
	Node delete(Node root, int key) 
    { 
        /* Base Case: If the tree is empty */
        if (root == null)  return root; 
  
        /* Otherwise, recur down the tree */
        if (key < root.key) 
            root.left = delete(root.left, key); 
        else if (key > root.key) 
            root.right = delete(root.right, key); 
  
        // if key is same as root's key, then This is the node 
        // to be deleted 
        else
        { 
            // node with only one child or no child 
            if (root.left == null) 
                return root.right; 
            else if (root.right == null) 
                return root.left; 
  
            // node with two children: Get the inorder successor (smallest 
            // in the right subtree) 
            root.key = minValue(root.right); 
  
            // Delete the inorder successor 
            root.right = delete(root.right, root.key); 
        } 
  
        return root; 
    } 
	void insert(int key) { 
	       root = insert(root, key); 
	    } 
	int minValue(Node root) 
    { 
        int minv = root.key; 
        while (root.left != null) 
        { 
            minv = root.left.key; 
            root = root.left; 
        } 
        return minv; 
    } 
	void deleteKey(int key) 
    { 
        root = delete(root, key); 
    }
	public static void main(String[] args) {
		Bst tree=new Bst();
		tree.insert(2);
		tree.insert(34);
		tree.insert(878);
		tree.insert(98);
		tree.insert(234);
		tree.insert(8);
		tree.insert(7);
		tree.insert(123);
		tree.insert(7879);
		tree.insert(45);
		tree.insert(123);
		tree.inorder(tree.root);
		System.out.println();
        tree.deleteKey(7); 
        tree.inorder(tree.root); 
       
        
        










		
	}

}
