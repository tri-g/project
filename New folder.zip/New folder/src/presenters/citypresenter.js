import{gettodaystemplate,getforecasttable} from '../utils/parser.js';
export const rendercity=({today,forecast,timezoneresponse})=>{
	const domelement=document.querySelector('.js-city-weather');
	const todaydata=gettodaystemplate(today,timezoneresponse);
	const forecastdata=getforecasttable(forecast,timezoneresponse)(0,2);

	domelement.innerHTML=`${todaydata}${forecastdata}`;
}