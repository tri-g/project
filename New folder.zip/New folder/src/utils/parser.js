import moment from 'moment-timezone';
export const getcity=response=>response.name;

export const getcountry=response=>response.sys.country;

export const getweatherdata=response=>`${response.weather[0].main}(${response.weather[0].description})`;

export const gettodaystemperature=response=>
`Temperature(min,average,max): `+
`${response.main.temp_min},${response.main.temp},${response.main.temp_max}`;

export const getsunrisesunset=(weatherresponse,timezoneresponse)=>{
	const{timeZoneId}=timezoneresponse;
	const{sunrise,sunset}=weatherresponse.sys;
	const sunriseTs=parseInt(sunrise,10)*1000;
	const sunsetTs=parseInt(sunset,10)*1000;
	const sunriseHhMm=moment.tz(sunriseTs,timeZoneId).format('HH:mm');
	const sunsetHhMm=moment.tz(sunsetTs,timeZoneId).format('HH:mm');
	return `Sunrise: ${sunriseHhMm}, Sunset: ${sunsetHhMm}`;
};

export const gettodaystemplate=(weather,timezone)=>`<div>${getcity(weather)},${getcountry(weather)}:${getweatherdata(weather)}</div><div>${gettodaystemperature(weather)}</div><div>${getsunrisesunset(weather,timezone)}</div>`.trim();

export const getforecastrow=(weather,timezone)=>rownumber=>{
	const row=weather.list[rownumber];
	const date=moment.tz(row.dt*1000,timezone.timeZoneId).format('MMM Do');
	return `
	<tr><td>${date}</td><td>${row.weather[0].main}(${row.weather[0].description})</td></tr>`.trim();
}
const getforecasttablebody=(rowtemplatefunction,currentrow,lastrow,accumulator)=>
currentrow>lastrow?accumulator:
getforecasttablebody(
	rowtemplatefunction,currentrow+1,lastrow,`${accumulator}${rowtemplatefunction(currentrow)}`);

export const getforecasttable=(weather,timezone)=>(firstrow,lastrow)=>{
	const rowtemplate=getforecastrow(weather,timezone);
	const tablebody=getforecasttablebody(rowtemplate,firstrow,lastrow,'');
	return `
	<table><td>Date</td><td>Weather description</td></tr>${tablebody}</table>`.trim();
};