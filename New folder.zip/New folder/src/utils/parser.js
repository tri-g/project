import moment from 'moment-timezone';
export const getcity=response=>response.name;

export const getcountry=response=>response.sys.country;

export const getweatherdata=response=>`${response.weather[0].main}(${response.weather[0].description})`;

export const gettodaystemperature=response=>
`Temperature(min,average,max): `+
`${response.main.temp_min}, ${response.main.temp}, ${response.main.temp_max}`;

export const getsunrisesunset=(weatherresponse,timezoneresponse)=>{
	const{timeZoneId}=timezoneresponse;
	const{sunrise,sunset}=weatherresponse.sys;
	

  var a1 = new Date(sunrise * 1000).toLocaleTimeString();
/*  var hour1 = a1.getHours();
  var min1 = a1.getMinutes();
  var time1 = hour1 + ':' + min1 ;*/


   var a2 = new Date(sunset * 1000).toLocaleTimeString();
  /*var hour2 = a2.getHours();
  var min2 = a2.getMinutes();
  var time2 = hour2 + ':' + min2 ;*/





	return `Sunrise: ${a1}, Sunset: ${a2}`;
};

export const gettodaystemplate=(weather,timezone)=>`<div>${getcity(weather)},${getcountry(weather)}:${getweatherdata(weather)}</div><div>${gettodaystemperature(weather)}</div><div>${getsunrisesunset(weather,timezone)}</div>`.trim();

export const getforecastrow=(weather,timezone)=>rownumber=>{
	const row=weather.list[rownumber];
	const date=moment.tz(row.dt*1000,timezone.timeZoneId).format('MMM Do');
	return `
	<tr><td style="border: 1px solid black; padding: 8px;">${date}</td><td style="border: 1px solid black; padding: 8px;">${row.main.feels_like}</td><td style="border: 1px solid black; padding:8px;">${row.weather[0].main}(${row.weather[0].description})</td></tr>`.trim();
}
const getforecasttablebody=(rowtemplatefunction,currentrow,lastrow,accumulator)=>
currentrow>lastrow?accumulator:
getforecasttablebody(
	rowtemplatefunction,currentrow+1,lastrow,`${accumulator}${rowtemplatefunction(currentrow)}`);

export const getforecasttable=(weather,timezone)=>(firstrow,lastrow)=>{
	const rowtemplate=getforecastrow(weather,timezone);
	const tablebody=getforecasttablebody(rowtemplate,firstrow,lastrow,'');
	return `
	<table style="border: 1px solid black; border-collapse: collapse;"><tr><th style="border: 1px solid black; padding: 15px;">Date</th><th style="border: 1px solid black; padding: 15px;">Temperature (C)</th><th style="border: 1px solid black; padding: 15px;">Weather description</th></tr>${tablebody}</table>`.trim();
};