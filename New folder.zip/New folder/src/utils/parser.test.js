import {expect} from 'chai';
import{getcity,getcountry,getweatherdata,gettodaystemperature,getsunrisesunset,gettodaystemplate,getforecastrow,getforecasttable} from './parser';

describe('parser util',()=>{
	it('shud return the city',()=>{
		expect(getcity({name:'City'})).to.equal('City');
	});
	it('shud return the country',()=>{
		expect(getcountry({
			sys:{
				country:'COUNTRY_CODE'
			}
		})).to.equal('COUNTRY_CODE')

	});
	it('shud return the weather condition and description',()=>{
		const input={
			weather:[
			{
				main:'Clouds',
				description:'scattered clouds'
			}]
		};
		const response='Clouds(scattered clouds)';
		expect(getweatherdata(input)).to.equal(response);
	});
	it('shud return todays temperature',()=>{
		const input={
			main:{
				temp: 20,
				temp_min: 18,
				temp_max: 22
			}
			
		};
		const response='Temperature(min,average,max): 18,20,22';
		expect(gettodaystemperature(input)).to.equal(response);
	});
	it('shud return the sunrise and sunset time',()=>{
		const weatherinput={
			sys:{
				sunrise:1494966143,
				sunset:1495004757
			}
		};
		const timezoneinput={
			timeZoneId:'Australia/Brisbane'
		};
		const response='Sunrise: 06:22, Sunset: 17:05';
				expect(getsunrisesunset(weatherinput,timezoneinput)).to.equal(response);


	});
	it('shud return the full template for today',()=>{
		const weatherinput={
			main:{
				temp: 20,
				temp_min: 18,
				temp_max: 22
			},
			weather:[
			{
				main:'Clouds',
				description:'scattered clouds'
			}],
			sys:{
				country:'COUNTRY_CODE',
				sunrise:1494966143,
				sunset:1495004757
			},
			name:'City'
		};
		const timezoneinput={
			timeZoneId:'Australia/Brisbane'
		}
		const response=`<div>City,COUNTRY_CODE:Clouds(scattered clouds)</div><div>Temperature(min,average,max): 18,20,22</div><div>Sunrise: 06:22, Sunset: 17:05</div>`.trim();
		expect(gettodaystemplate(weatherinput,timezoneinput)).to.equal(response);
	});
	it('shud return a forecast row',()=>{
		const forecastresponse={
			list:[{
				dt:1497661200,
				weather:[{
					main:'Sunny',
					description:'sky is clear'
				}]
			},
			{
				dt:1497747600,
				weather:[{
					main:'Clouds',
					description:'broken clouds'
				}]
			}	]
		};
		const timezoneresponse={
			timeZoneId:'Australia/Brisbane'
		};
		const firstrow=getforecastrow(forecastresponse,timezoneresponse)(0);
		const secondrow=getforecastrow(forecastresponse,timezoneresponse)(1);
		const expectedfirstrow=`
		<tr><td>Jun 17th</td><td>Sunny(sky is clear)</td></tr>`.trim();
		const expectedsecondrow=`
		<tr><td>Jun 18th</td><td>Clouds(broken clouds)</td></tr>`.trim();
		expect(firstrow).to.equal(expectedfirstrow);
		expect(secondrow).to.equal(expectedsecondrow);
	});
	it('shud return the full forecast table',()=>{
		const forecastresponse={
			list:[{
				dt:1497661200,
				weather:[{
					main:'Sunny',
					description:'sky is clear'
				}]
			},
			{
				dt:1497747600,
				weather:[{
					main:'Clouds',
					description:'broken clouds'
				}]
			}	]
		};
		const timezoneresponse={
			timeZoneId:'Australia/Brisbane'
		};
		const table=getforecasttable(forecastresponse,timezoneresponse)(0,1);
		const expectedresult=`
		<table><tr><td>Date</td><td>Weather description</td></tr><tr><td>Jun 17th</td><td>Sunny(sky is clear)</td></tr><tr><td>Jun 18th</td><td>Clouds(broken clouds)</td></tr></table>`.trim();
		expect(table).to.equal(expectedresult);


	});
});