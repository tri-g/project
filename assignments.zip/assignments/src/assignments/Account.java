package assignments;

public class Account {
	public long no;
	public String name;

	
	public Account() {
		
		this.no = 56778876l;
		this.name = "Tony";
	}
	

}
