package assignments;

public interface IPayment {
	public void pay(double amount);

}
