package assignments;

public class Prog7 {
	public static void main(String[] args)
	{
	String s = "India"; 
    StringBuilder input1 = new StringBuilder(); 
    input1.append(s); 
    input1 = input1.reverse(); 
    System.out.println("Reversed string is: "+input1); 
    System.out.println("Length of the string is: "+s.length());
    System.out.println("First index: "+s.charAt(0));
    System.out.println("Last index: "+s.charAt(s.length()-1));
}		
}
