package assignments;

public class Prog6_2 {
	public static void main(String[] args) {
		int x=40;
		int y=10;
		int sum=x+y;
		int sub=x-y;
		int mul=x*y;
		float div=x/y;
		float mod=x%y;
		System.out.println("addition: "+sum);
		System.out.println("difference: "+sub);
		System.out.println("multiplication: "+mul);
		System.out.println("division: "+div);
		System.out.println("modulus: "+mod);
System.out.println();
 int q,w,e;
 q=y++ + y++ + ++y + --y -y;
 System.out.println(q);
 System.out.println();
 w=y>>1;
 System.out.println(w);
 System.out.println();
 e=x<<3;
 System.out.println(e);



	}

}
