package assignments;

import java.util.function.Predicate;

public class FruitPredicate  {
	
	public static Predicate<Fruit> isRed()
	{
		return c->c.getColor().equalsIgnoreCase("red");		
	}
	
}
