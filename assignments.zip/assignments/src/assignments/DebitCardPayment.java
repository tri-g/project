package assignments;

public class DebitCardPayment {
	public void pay(double amount)
	{
		int service_tax=5;
		float a=(float)amount*service_tax/100;
		System.out.println("Service tax: "+service_tax);
		System.out.println("Debit card amount:"+a);
	}

}
