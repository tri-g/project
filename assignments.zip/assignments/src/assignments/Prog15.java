package assignments;

import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.TreeSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;

public class Prog15 {
	public void arraylisteg()
	{
		System.out.println("-----------------Array List-----------------------");
		List<String> list=new ArrayList<String>();  
	      list.add("Joey");
	      list.add("Chandler");
	      list.add("Phoebe");
	      list.add("Rachel");
	      list.add("Monica");
	      list.add(5,"Ross");
	      System.out.println(list); 
	}
	public void treeseteg()
	{
		System.out.println("-----------------Tree Set-----------------------");
		TreeSet<String> food = new TreeSet<String>();
		food.add("Biryani");
		food.add("Pani puri");
		food.add("Noodles");
		food.add("Chicken roll");
		food.add("Pav baji");
		System.out.println(food);
	}
	public void hashseteg() 
	{
		System.out.println("-----------------Hash Set-----------------------");
		 HashSet<String> hset =  new HashSet<String>();
	      hset.add("Australia");
	      hset.add("London");
	      hset.add("Canada");
	      hset.add("Scotland");
	      hset.add(null);
	      System.out.println(hset);
	}
	public void hashmapeg()
	{
		System.out.println("-----------------Hash Map-----------------------");
		HashMap<String, Integer> map = new HashMap<>(); 
		map.put("Basketball", 1); 
		map.put("Kabbadi",2); 
		map.put("Badmintton", 3); 
		System.out.println("Size of map is: "+ map.size()); 
		System.out.println(map);
	}
	public void queueeg()
	{
		System.out.println("-----------------Queue-----------------------");
		Queue<String> q = new PriorityQueue<String>();
	      q.add("Eat");
	      q.add("Sleep"); 
	      q.add("Watch TV");
	      q.add("Play games");
	      q.add("Repeat");
		  System.out.println(q);
	}

}
