package assignments;

public class Prog8 {
	private String pastry_type;
	private String flavour;
	private int quantity;
	
	public String getPastry_type() {
		return pastry_type;
	}
	public void setPastry_type(String pastry_type) {
		this.pastry_type = pastry_type;
	}
	public String getFlavour() {
		return flavour;
	}
	public void setFlavour(String flavour) {
		this.flavour = flavour;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
}
