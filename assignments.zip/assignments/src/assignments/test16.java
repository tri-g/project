package assignments;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class test16 {
	public static void main(String[] args) {
		ImportantDates[] d = new ImportantDates[2];
		 
		d[0] = new ImportantDates(15, 23, 24);
		d[1] = new ImportantDates(1, 29, 6);		 
		Arrays.sort(d);
		System.out.println(Arrays.toString(d));
		

	}

}
