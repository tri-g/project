package assignments;

public class test11 {

	public static void main(String[] args) {
		CreditCardPayment c=new 		CreditCardPayment();
		DebitCardPayment d=new DebitCardPayment();
		c.pay(2000);
		System.out.println();
		d.pay(200000);
	}

}
