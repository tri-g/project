package assignments;

public class test2 {

	public static void main(String[] args) {
		Prog2 dog=new Prog2("Marshmellow",1,"Husky");
		dog.display();
		
		
	
	}

}
