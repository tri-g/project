package com.cts.app;
import com.cts.beans.Product;
public class ProductClient {
	public static void main(String[] args) {
		Product p=new Product();
		p.code=1;
		p.name="Book";
		p.price=500f;
p.display();		
	}

}
